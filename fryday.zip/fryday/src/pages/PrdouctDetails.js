import React from 'react';

const ProductDetails = () => {
    return (
        <div className="container">
            <div className="productDetails d-flex my-3">
                <div className="product-image w-50">
                    <img src="carousel_1.jpg" alt="" />
                </div>
                <div className="product-info">
                    <p className="product_name">
                        Smart LG TV with wifi & bluetooth.
                    </p>
                    <div class="product_rating d-flex">
                        <div class="p-0">
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                            <i className="fa fa-star"></i>
                        </div>
                        <p className="mt-1 mx-2">(2.24)</p>
                    </div>
                    <div class="Inches  my-4">
                        <span>Chooce Inches</span>
                        <div class="d-flex my-0">
                            <div class="24inches mx-1"><b>24"</b></div>
                            <div class="32inches mx-1"><b>32"</b></div>
                            <div class="42inches mx-1"><b>42"</b></div>
                            <div class="48inches mx-1"><b>48"</b></div>
                        </div>

                    </div>
                    <div class="product_price_div d-flex">
                        <p class="product_price mx-2">$120.30</p>
                        <p class="product_previous_price"><small><i>$190.70</i></small></p>
                    </div>

                    <div class="d-flex">
                        <div class="d-flex mx-3">
                            <span style="border: 1px solid black; width: 20px; text-align: center; margin-right: -1px;">-</span>
                            <input type="text" class="form-field" style="width: 30px; text-align: center;" value="1"/>
                                <span style="border: 1px solid black; width: 20px; text-align: center; margin-left: -1px;">+</span>
                        </div>
                        <a href="" class="product_order_btn btn">Add To Cart</a>
                    </div>
                </div>
            </div>
            <hr />
            <div className="row">
                <div className="col-lg-2">
                    <div className="card alternativeProducts">
                        <div className="card-body">
                            Extra products
                        </div>
                    </div>
                </div>

            </div>
            <hr />
            <div className="product_details">
                <div className="product_description_info">
                    This products is the best with the best features that you could ever find. This has in bult speackers
                    ,Wifi , bluetooth, Charger, Free gifts, 3d led screen and many more.
                </div>

                <hr />

                <div>
                    <ul className="list-group">
                        <li className="list-group-item Description">
                            Description
                        </li>
                        <li className="list-group-item bg-dark text-light">
                            Bluetooth - version 3.1
                        </li>
                        <li className="list-group-item bg-dark text-light">
                            Screen - 3D Layered
                        </li>
                        <li className="list-group-item bg-dark text-light">
                            Processor - Octacor
                        </li>
                        <li className="list-group-item bg-dark text-light">
                            front Comera - 12mp
                        </li>
                        <li className="list-group-item bg-dark text-light">
                            Back Comera - 54mp
                        </li>
                    </ul>
                </div>
            </div>
        </div>
};

export default Home;
