import React from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import productDetails from './pages/Productdetails'
import Cart from './pages/Cart';
import Login from './pages/Login'
imprt Shipping from './pages/Shipping'
//import FilteredItems from './pages/Filter';
import './App.css';


const App = () => {
    return (

        <Router>
            <div>
            <div className="container-fluid">
                <nav className="top-nav">
                    <div className="d-flex justify-content-between">
                        <div>
                            <p>Blog</p>
                        </div>
                        <div className="d-flex justify-content-between">
                            <div className="userInfo mx-5">
                                <p>
                                    <i className="fa fa-user-circle mx-3"></i>
                                    Clients Name
                                </p>
                            </div>

                            <div className="socials d-flex justify-content-around mx-3">
                                <i className="fa fa-facebook" aria-hidden="true"></i>
                                <i className="fa fa-instagram"></i>
                                <i className="fa fa-youtube"></i>
                            </div>
                        </div>
                    </div>
                    <div className="navtabdiv">
                        <div className="d-lg-flex align-items-center">
                            <div className="webName d-flex align-items-center">
                                <i className="fa fa-shop webLogo"></i>
                                <h2 className="mx-3" ><span>F</span>ryday</h2>
                            </div>

                            <div className="subNavdiv">
                                <ul className="navTabs">
                                    <li className="NavItems">
                                        <a to='/'>Home</a>
                                    </li>
                                    <li className="NavItems">
                                        <a to="">Shop</a>
                                    </li>
                                    <li className="NavItems">
                                        <a href="">Men</a>
                                    </li>
                                    <li className="NavItems">
                                        <a href="">Women</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div className="cartLovePrice float-right mx-5">
                            <div>
                                <i className="fa fa-heart heartLogo"></i>
                            </div>
                            <div className="mx-lg-5">
                                <a to="Cart">
                                <i className="fa fa-shopping-cart"></i>
                                </a>
                            </div>
                            <div>
                                <p>
                                    <span><b>Price</b></span>
                                    <br />
                                    <span className="mt-0"><small>0.00</small></span>
                                </p>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <div class="conteiner-fluid p-3 search_div">
                <div class="input-group mb-3 search-box">
                    <input type="text" class="form-control" placeholder="Enter Search..." aria-label="Recipient's username" aria-describedby="basic-addon2"/>
                    <div class="input-group-append">
                        <span class="input-group-text" id="basic-addon2">Search</span>
                    </div>
                </div>
            </div>
            </div>


           
            <Route exact path="/" component={Home} />
            <Route path="/cart" component={Cart} />
            <Route path="/login" component={Login} />
            <Route path="/shipping" component={Shipping} />
            <Route path="/productDetails" component={productDetails} />
        </Router>
        

            
        //</Router>
    );
};

export default App;
